#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "fonction.h"
char id[30],idrech[30];
GtkWidget *windowcapteurs;
char id[30],idrech[30],in[30];int v=0 ;;
GtkWidget *windowouvrier;
GtkWidget *windowtroupeaux;
GtkWidget *gestion;
GtkWidget *windowplantation;
int x1=1;
int x2=1;

int x=1;
int yg=1;


void
on_buttonlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *a2, *b2, *window3 , *cc,*window4;
char a3[20];
char b3[20];
int trouve;
cc=lookup_widget(button,"label132");
a2 = lookup_widget (button, "entrylogin");
b2 = lookup_widget (button, "entryloginpass");
strcpy(a3, gtk_entry_get_text(GTK_ENTRY(a2)));
strcpy(b3, gtk_entry_get_text(GTK_ENTRY(b2)));
trouve=verif(a3,b3);
if(trouve==1)
{
window3=create_windowmenu();
gtk_widget_show (window3);
window4=create_windowlogin();
gtk_widget_hide(window4);

}
else 
gtk_label_set_text(GTK_LABEL(cc),"Créer un compte pour connecter ");
}


void
on_buttoninscription_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_windowinscription();
gtk_widget_show (window);
}


void
on_buttoninscri_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *a, *b,*c,*d,*e,*window2,*verifier;
char a1[20];
char b1[20];
char c1[20];
char d1[20];
char e1[20];

int verif;
a = lookup_widget (button, "entryinscrinom");
b = lookup_widget (button, "entryinscriprenom");
c = lookup_widget (button, "entryinscricin");
d = lookup_widget (button, "entryinscripass");
e = lookup_widget (button, "entryinscripasscheck");
verifier = lookup_widget (button, "label133");
strcpy(a1, gtk_entry_get_text(GTK_ENTRY(a)));
strcpy(b1, gtk_entry_get_text(GTK_ENTRY(b)));
strcpy(c1, gtk_entry_get_text(GTK_ENTRY(c)));
strcpy(d1, gtk_entry_get_text(GTK_ENTRY(d)));
strcpy(e1, gtk_entry_get_text(GTK_ENTRY(e)));
verif=checkpassword(d1,e1);
if (verif==1)
	{f=fopen("inscription.txt", "a");
		if(f!=NULL)
		{
		fprintf(f,"%s %s %s %s %s \n",a1,b1,c1,d1,e1);
		fclose(f);
		window2=create_windowlogin();
		gtk_widget_show (window2);}
	}
else
		gtk_label_set_text(GTK_LABEL(verifier),"Vérifier votre mot de passe ");
}


void
on_buttongestionouvrier_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99,*window4;
window99=create_windowouvrier();
gtk_widget_show (window99);
window4=create_windowmenu();
gtk_widget_hide(window4);
}


void
on_DBbuttonmenuprincipal_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowmenu();
gtk_widget_show (window99);
}


void
on_DBbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier o;
GtkWidget *windowouvrier;
GtkWidget *DBentrycin;
GtkWidget *DBtreeview;
FILE*f;
FILE*f2;


windowouvrier=lookup_widget(button,"windowouvrier");
DBentrycin=lookup_widget(button,"DBentrycin");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(DBentrycin)));
f=fopen("ouvrier.bin","rb");

 if(f!=NULL)
 {
  while(fread(&o,sizeof(ouvrier),1,f))
    {
     
    if ((strcmp(o.cin,idrech)==0))
    {
    f2=fopen("DBrecherche.bin","ab+");
    if  (f2!=NULL) 
       {fwrite(&o,sizeof(ouvrier),1,f2);
     
       fclose(f2);
       }
    }

 }
 fclose(f);
}
DBtreeview=lookup_widget(windowouvrier,"DBtreeview");
     DBrecherche(DBtreeview);
remove("DBrecherche.bin");
}



void
on_DBbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier o;
    GtkWidget *DBtreeview;
	    windowouvrier=lookup_widget(button,"windowouvrier");
	    DBtreeview=lookup_widget(windowouvrier,"DBtreeview");
	    DBsuppression(id,o);
            DBaffichage(DBtreeview);
}


void
on_DBbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"DBnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"DBnotebook")));
}


void
on_DBbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *DBtreeview;
windowouvrier=lookup_widget(button,"windowouvrier");
DBtreeview=lookup_widget(windowouvrier,"DBtreeview");
DBaffichage(DBtreeview);
}


void
on_DBbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier o;char Type[30];
GtkWidget *DBentryajoutcin;
GtkWidget *DBentryajoutnom;
GtkWidget *DBentryajoutprenom;
GtkWidget *DBspinbuttonajoutjour;
GtkWidget *DBspinbuttonajoutmois;
GtkWidget *DBspinbuttonajoutannee;
GtkWidget *DBcomboboxajoutsexe;
GtkWidget *sortiea;

DBspinbuttonajoutjour=lookup_widget(button, "DBspinbuttonajoutjour");
DBspinbuttonajoutmois=lookup_widget(button, "DBspinbuttonajoutmois");
DBspinbuttonajoutannee=lookup_widget(button, "DBspinbuttonajoutannee");
DBcomboboxajoutsexe=lookup_widget(button, "DBcomboboxajoutsexe");
DBentryajoutcin=lookup_widget(button,"DBentryajoutcin");
DBentryajoutnom=lookup_widget(button,"DBentryajoutnom");
DBentryajoutprenom=lookup_widget(button,"DBentryajoutprenom");
sortiea=lookup_widget(button, "DBlabelmsgsucc");

strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(DBentryajoutcin)));
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(DBentryajoutnom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(DBentryajoutprenom)));
o.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonajoutjour));
o.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonajoutmois));
o.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(DBcomboboxajoutsexe)));
strcpy(o.sexe,Type);
DBajout(o);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}



void
on_DBbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier o;char Type[30];
GtkWidget *DBcomboboxmodifsexe;
GtkWidget *DBentrymodifcin;
GtkWidget *DBentrymodifnom;
GtkWidget *DBspinbuttonmodifjour;
GtkWidget *DBspinbuttonmodifmois;
GtkWidget *DBspinbuttonmodifannee;
GtkWidget *DBentrymodifprenom;
GtkWidget *sortiem;    
	
DBspinbuttonmodifjour=lookup_widget(button, "DBspinbuttonmodifjour");
DBspinbuttonmodifmois=lookup_widget(button, "DBspinbuttonmodifmois");
DBspinbuttonmodifannee=lookup_widget(button, "DBspinbuttonmodifannee");
DBcomboboxmodifsexe=lookup_widget(button, "DBcomboboxmodifsexe");
DBentrymodifcin=lookup_widget(button,"DBentrymodifcin");
DBentrymodifnom=lookup_widget(button,"DBentrymodifnom");
DBentrymodifprenom=lookup_widget(button,"DBentrymodifprenom");
sortiem=lookup_widget(button, "DBlabelmodifreus");

strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(DBentrymodifcin)));
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(DBentrymodifnom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(DBentrymodifprenom)));
o.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonmodifjour));
o.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonmodifmois));
o.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(DBspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(DBcomboboxmodifsexe)));
strcpy(o.sexe,Type);
DBmodification(id,o);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_DBbutton1tache2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
pointage p;
GtkWidget *cinn;
GtkWidget *jourr;
GtkWidget *moiss;
GtkWidget *anneee;
cinn=lookup_widget(button,"DBentry1tache2");
jourr=lookup_widget(button, "DBspinbutton1tache2");
moiss=lookup_widget(button, "DBspinbutton2tache2");
anneee=lookup_widget(button, "DBspinbutton3tache2");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(cinn)));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourr));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moiss));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneee));


if(x==1)
{p.present=1;}

else 
{p.present=0;}
presence ( p);


}



void
on_DBbutton2tache2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *sortiem;
GtkWidget *ta;
GtkWidget *pourcent ;
int mm;
int aa;
pointage p;
int tauxpresence=0;
char tauxtxt[200];
double absence;
double i=0;
float tauxabsence;
FILE *f=NULL;
mois=lookup_widget(button, "DBspinbutton4tache2");
annee=lookup_widget(button, "DBspinbutton5tache2");
mm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
aa=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
sortiem=lookup_widget(button, "DBlabel35tache2");
ta=lookup_widget(button, "DBlabel38tache2");
pourcent=lookup_widget(button, "DBlabel39tache2");

    f=fopen("pointage.txt","r");
    if(f!=NULL)
    {
        while((fscanf(f, "%s %d %d %d %d",p.cin,&p.date.jour,&p.date.mois,&p.date.annee,&p.present)!=EOF))

{
if((p.date.mois==mm)&&(p.date.annee==aa))

{
i++;
tauxpresence=tauxpresence+p.present;
}
}
fclose(f);
}
absence=i-tauxpresence;
tauxabsence=(absence/i)*100;

sprintf(tauxtxt,"%.2f",tauxabsence);
gtk_label_set_text(GTK_LABEL(ta),"Le taux d`absence est :");
gtk_label_set_text(GTK_LABEL(pourcent),"%");
gtk_label_set_text(GTK_LABEL(sortiem),tauxtxt);

return 0;
}






void
on_DBtreeview_row_activated            (GtkTreeView     *DBtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
gchar *cin;
        gchar *nom;
        gchar *prenom;

	GtkTreeModel *Model = gtk_tree_view_get_model(DBtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);
				gtk_tree_model_get (Model,&iter,1,&cin,2,&nom,4,&prenom,-1);//recuperer les information de la ligne selectionneé
		//remplir les champs de entry
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowouvrier,"DBentrymodifcin")),cin);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowouvrier,"DBentrymodifnom")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(windowouvrier,"DBentrymodifprenom")),prenom);
		
}
}








void
on_ABbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;
GtkWidget *windowtroupeaux;
GtkWidget *ABentryid;
GtkWidget *ABtreeview;
FILE*f;
FILE*f2;


windowtroupeaux=lookup_widget(button,"windowtroupeaux");
ABentryid=lookup_widget(button,"ABentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(ABentryid)));
f=fopen("animaux.bin","rb");

 if(f!=NULL)
 {
  while(fread(&a,sizeof(ANIMAL),1,f))
    {
     
    if ((strcmp(a.identifiant,idrech)==0))
    {
    f2=fopen("ABrecherche.bin","ab+");
    if  (f2!=NULL) 
       {fwrite(&a,sizeof(ANIMAL),1,f2);
     
       fclose(f2);
       }
    }

 }
 fclose(f);
}
ABtreeview=lookup_widget(windowtroupeaux,"ABtreeview");
     ABrecherche(ABtreeview);
remove("ABrecherche.bin");
}


void
on_ABstatistique_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

int *b,*v,a=0,c=0;
char chv[30],chb[30];
b=&a;
v=&c;
GtkWidget *labelBrebi;
GtkWidget *labelVeau;
GtkWidget *windowtroupeaux;
ANIMAL e;
windowtroupeaux= lookup_widget(button,"windowtroupeaux");
 gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"ABnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"ABnotebook")));
 gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"ABnotebook")));
                


labelBrebi=lookup_widget(windowtroupeaux,"labelb");
labelVeau=lookup_widget(windowtroupeaux,"labelv");
nombre(b,v);
sprintf(chb,"%d",a);
sprintf(chv,"%d",c);
gtk_label_set_text(labelBrebi,chb);
gtk_label_set_text(labelVeau,chv);


}


void
on_ABbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtroupeaux;
ANIMAL a;
    GtkWidget *ABtreeview;
	    windowtroupeaux=lookup_widget(button,"windowtroupeaux");
	    ABtreeview=lookup_widget(windowtroupeaux,"ABtreeview");
	    ABsuppression(id,a);
            ABaffichage(ABtreeview);
}





void
on_ABbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtroupeaux;
GtkWidget *ABtreeview;
windowtroupeaux=lookup_widget(button,"windowtroupeaux");
ABtreeview=lookup_widget(windowtroupeaux,"ABtreeview");
ABaffichage(ABtreeview);

}

//////////////OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
void
on_ABtreeview_row_activated            (GtkTreeView     *ABtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(ABtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}

}


void
on_ABbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;char Type[30];char a1[20];char a2[20];char a3[20];char a4[20];
GtkWidget *ABentryajoutid;
GtkWidget *ABentryajoutsexe;
GtkWidget *ABentryajoutpoids;
GtkWidget *ABspinbuttonajoutjour;
GtkWidget *ABspinbuttonajoutmois;
GtkWidget *ABspinbuttonajoutannee;
GtkWidget *ABcomboboxajouttype;
GtkWidget *sortiea;
 



ABspinbuttonajoutjour=lookup_widget(button, "ABspinbuttonajoutjour");
ABspinbuttonajoutmois=lookup_widget(button, "ABspinbuttonajoutmois");
ABspinbuttonajoutannee=lookup_widget(button, "ABspinbuttonajoutannee");
ABcomboboxajouttype=lookup_widget(button, "ABcomboboxajouttype");
ABentryajoutid=lookup_widget(button,"ABentryajoutid");
ABentryajoutpoids=lookup_widget(button,"ABentryajoutpoids");
sortiea=lookup_widget(button, "ABlabelmsgsucc");
if(x1==1)


strcpy(a.sexe,"Male");

else
{

strcpy(a.sexe,"Femelle");
}







strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(ABentryajoutid)));


strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(ABentryajoutpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonajoutjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonajoutmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ABcomboboxajouttype)));
strcpy(a.type,Type);
ABajout(a);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_ABbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
int b;
ANIMAL a;char Type[30];
GtkWidget *ABcomboboxmodiftype;
GtkWidget *ABentrymodifid;
GtkWidget *ABentrymodifsexe;
GtkWidget *ABspinbuttonmodifjour;
GtkWidget *ABspinbuttonmodifmois;
GtkWidget *ABspinbuttonmodifannee;
GtkWidget *ABentrymodifpoids;
GtkWidget *sortiem; 

ABspinbuttonmodifjour=lookup_widget(button, "ABspinbuttonmodifjour");
ABspinbuttonmodifmois=lookup_widget(button, "ABspinbuttonmodifmois");
ABspinbuttonmodifannee=lookup_widget(button, "ABspinbuttonmodifannee");
ABcomboboxmodiftype=lookup_widget(button, "ABcomboboxmodiftype");
ABentrymodifid=lookup_widget(button,"ABentrymodifid");

ABentrymodifpoids=lookup_widget(button,"ABentrymodifpoids");
sortiem=lookup_widget(button, "ABlabelmodifreus");
if(x1==1)


strcpy(a.sexe,"Male");

else
{

strcpy(a.sexe,"Femelle");
}

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(ABentrymodifid)));

strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(ABentrymodifpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonmodifjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonmodifmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ABspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ABcomboboxmodiftype)));
strcpy(a.type,Type);
ABmodification(id,a);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_ABbutton6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window22;
window22=create_windowtroupeaux();
gtk_widget_show (window22);
}


void
on_ABbuttonmodifier_clicked            (GtkButton       *windowtroupeaux,
                                        gpointer         user_data)

{
		
  gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"ABnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"ABnotebook")));
		
}

//*************************************************************************************************************************



GtkWidget *eqag;
GtkWidget *treeaff;
GtkWidget *eg;
GtkWidget *output;




void
on_actaff_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}


void
on_marq_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_aff_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet_graphique,"equipement");
eg=lookup_widget(eqag,"eg");
treeaff=lookup_widget(eqag,"treeaff");
afficher_equipement(treeaff);
}



void
on_ajact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}





void
on_mschr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *emsref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat;
  equipement e;
  char ref[9] ;
 

  
  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
  
  e=rechercher(ref);

  FILE* f;
  f=fopen("equip.txt","r");
 
  nom=lookup_widget (objet,"emsn");
  marque=lookup_widget (objet,"emsm");
  jour=lookup_widget (objet,"spinbuttonmsaj");
  mois=lookup_widget (objet,"spinbuttonmsam");
  annee=lookup_widget (objet,"spinbuttonmsaa");
  jourm=lookup_widget (objet,"spinbuttonmsmj");
  moism=lookup_widget (objet,"spinbuttonmsmm");
  anneem=lookup_widget (objet,"spinbuttonmsma");
  etat=lookup_widget (objet,"emse");
  gtk_entry_set_text (GTK_ENTRY(emsref),e.ref);
  gtk_entry_set_text (GTK_ENTRY(nom),e.nom);
  gtk_entry_set_text (GTK_ENTRY(marque),e.marque);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),e.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),e.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),e.annee);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jourm),e.jourm);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(moism),e.moism);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(anneem),e.anneem);
  gtk_entry_set_text (GTK_ENTRY(etat),e.etat);
  
  
  

  
  fclose(f);
}


void
on_msmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *emsref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat;
  equipement e1;
  char ref[9] ;
 

  
  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
  
  e1=rechercher(ref);

  FILE* f;
  f=fopen("equip.txt","r");
 
  nom=lookup_widget (objet,"emsn");
  marque=lookup_widget (objet,"emsm");
  jour=lookup_widget (objet,"spinbuttonmsaj");
  mois=lookup_widget (objet,"spinbuttonmsam");
  annee=lookup_widget (objet,"spinbuttonmsaa");
  jourm=lookup_widget (objet,"spinbuttonmsmj");
  moism=lookup_widget (objet,"spinbuttonmsmm");
  anneem=lookup_widget (objet,"spinbuttonmsma");
  etat=lookup_widget (objet,"emse");
  
strcpy(e1.ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e1.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(e1.etat,gtk_entry_get_text(GTK_ENTRY(etat)));



e1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
e1.jourm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourm));
e1.moism=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moism));
e1.anneem=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneem));




  modifier_equipement(e1);
  fclose(f);
}


void
on_mssup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *nom, *emsref, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *etat, *outpout;
  equipement e;
char ref[9];
int suppri;
  FILE* f;

  emsref=lookup_widget(objet, "emsref");
  strcpy(ref,gtk_entry_get_text(GTK_ENTRY(emsref)));
   
   outpout=lookup_widget (objet,"err");
   suppri=supprimer_equipement(e,ref);
  if (suppri==1)
   {
  gtk_label_set_text (GTK_LABEL(outpout),"equipement supprimé");
	printf("equipement supprimé");
   }

}


void
on_msact_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
eqag=lookup_widget(objet, "equipement");
gtk_widget_destroy(eqag);
eqag=create_equipement();
gtk_widget_show(eqag);
}

//****************************************************************************************************************

void
on_YGbutton4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window22;
window22=create_equipement();
gtk_widget_show (window22);
}


void
on_ajaj_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
equipement e;

GtkWidget *ref, *nom, *marque, *jour, *mois, *annee, *jourm, *moism, *anneem, *bon, *def;

eqag=lookup_widget(objet, "equipement");

ref=lookup_widget(objet, "eajref");
nom=lookup_widget(objet, "eajn");
marque=lookup_widget(objet, "eajm");
jour=lookup_widget(objet, "spinbuttonajaj");
mois=lookup_widget(objet, "spinbuttonajam");
annee=lookup_widget(objet, "spinbuttonajaa");
jour=lookup_widget(objet, "spinbuttonajmj");
mois=lookup_widget(objet, "spinbuttonajmm");
annee=lookup_widget(objet, "spinbuttonajma");
bon=lookup_widget(objet, "radiobuttonajeb");
def=lookup_widget(objet, "radiobuttonajed");

strcpy(e.ref,gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(marque)));

e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
e.jourm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourm));
e.moism=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moism));
e.anneem=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneem));

if (yg==1)
	{strcpy(e.etat,"bonne_etat");}
else 	{strcpy(e.etat,"defectueux");}

ajouter_equipement(e);
}


void
on_radiobuttonajeb_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){yg=1;}
}


void
on_radiobuttonajed_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){yg=0;}
}



//************************************************************************************




void
on_DBradiobutton2tache22_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x=0;}

}


void
on_DBradiobutton1tache22_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x=1;}

}








void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
 client c;
GtkWidget *entryNom;
GtkWidget *entryCin;
GtkWidget *entryPrenom;
GtkWidget *entryAdresse;
GtkWidget *entryNumtel;
GtkWidget *entrysex;
GtkWidget *labelCin;
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labeladresse;
GtkWidget *labelnumtel;
GtkWidget *existe;
GtkWidget* success;
int b=1;



entryCin=lookup_widget(button,"entry5");
entryNom=lookup_widget(button,"entry1");
entryPrenom=lookup_widget(button,"entry2");
entryAdresse = lookup_widget (button,"entry4");
entryNumtel=lookup_widget(button,"entry3");


labelCin=lookup_widget(button,"label13");
labelnom=lookup_widget(button,"label7");
labelprenom=lookup_widget(button,"label8");
labeladresse=lookup_widget(button,"label9");
labelnumtel=lookup_widget(button,"label10");

existe=lookup_widget(button,"label34");
success=lookup_widget(button,"label35");

        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(entryCin) ) );
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
	strcpy(c.adresse, gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryAdresse)));
        strcpy(c.numtel,gtk_entry_get_text(GTK_ENTRY(entryNumtel) ) );
	

 gtk_widget_hide (success);
// controle saisie
if(strcmp(c.cin,"")==0){
		  gtk_widget_show (labelCin);
b=0;
}
else {
		  gtk_widget_hide(labelCin);
}

if(strcmp(c.nom,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}
if(strcmp(c.prenom,"")==0){
		  gtk_widget_show (labelprenom);
b=0;
}
else {
		  gtk_widget_hide(labelprenom);
}
if(strcmp(c.adresse,"")==0){
		  gtk_widget_show (labeladresse);
b=0;
}
else {
		  gtk_widget_hide(labeladresse);
}
if(strcmp(c.numtel,"")==0){
		  gtk_widget_show (labelnumtel);
b=0;
}
else {
		  gtk_widget_hide(labelnumtel);
}


if(b==1){

        if(exist_client(c.cin)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_client(c);

						  gtk_widget_show (success);
        }
//mise a jour du treeView
        GtkWidget* p=lookup_widget(button,"treeview1");

        AfficherClient(p,"clients.txt");
}

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
       	 client c;
	 
        strcpy(c.cin,gtk_label_get_text(GTK_LABEL(lookup_widget(button,"label20"))));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"entry6"))));
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"entry7"))));
        strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"entry9"))));
        strcpy(c.numtel,gtk_entry_get_text(GTK_ENTRY(lookup_widget(button,"entry8"))));
	
        supprimer_client(c.cin);
        ajouter_client(c);
//mise ajour du tree view 
        AfficherClient(lookup_widget(button,"treeview1"),"clients.txt");
		gtk_widget_show(lookup_widget(button,"label37"));



}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* cin;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        label=lookup_widget(button,"label23");
        p=lookup_widget(button,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&cin,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_client(cin);// supprimer la ligne du fichier

           gtk_widget_hide (label);}
else{
                gtk_widget_show (label);
        }


}

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelcin;
GtkWidget *nbResultat;
GtkWidget *message;
char cin[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entry10");
labelcin=lookup_widget(button,"label13");
p1=lookup_widget(button,"treeview2");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(cin,"")==0){
  gtk_widget_show (labelcin);b=0;
}else{
b=1;
gtk_widget_hide (labelcin);}

if(b==0){return;}else{

nb=ChercherClient(p1,"clients.txt",cin);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(button,"label27");
message=lookup_widget(button,"label26");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gchar *cin;
        gchar *nom;
        gchar *prenom;
        gchar *adresse;
        gchar *numtel;
	
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(gestion,"label37"));//cacher label modifier avec succees
		
                gtk_tree_model_get (model,&iter,0,&cin,1,&nom,2,&prenom,3,&adresse,4,&numtel,-1);//recuperer les information de la ligne selectionneé
		//remplir les champs de entry
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry6")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry7")),prenom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry9")),adresse);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry8")),numtel);

                GtkWidget* msgCin=lookup_widget(gestion,"label20");
                GtkWidget* msg1=lookup_widget(gestion,"label36");
                gtk_label_set_text(GTK_LABEL(msgCin),cin);
                gtk_widget_show(msgCin);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestion,"button4"));//afficher le bouton modifier
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));//redirection vers la page precedente
        }



}


void
on_menuclients_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
GtkWidget *p2;
int i,j,k;
gestion = create_gestion ();
p=lookup_widget(gestion,"treeview1");
p1=lookup_widget(gestion,"treeview2");

i=0;
j=0;
k=0;
AfficherClient(p,"clients.txt");
AfficherClient1(p1,"clients.txt");
gtk_widget_show (gestion);
}


void
on_ABbutton9_clicked                   (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *window99;
window99=create_windowmenu();
gtk_widget_show (window99);
}



void
on_YGbutton9_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowmenu();
gtk_widget_show (window99);
}


void
on_KCbutton10_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowmenu();
gtk_widget_show (window99);
}


void
on_AStreeview_row_activated            (GtkTreeView     *AStreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(AStreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AStreeview;
windowplantation=lookup_widget(button,"windowplantation");
AStreeview=lookup_widget(windowplantation,"AStreeview");
ASaffichage(AStreeview);
}


void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
	    GtkWidget *AStreeview;
	    windowplantation=lookup_widget(button,"windowplantation");
	    AStreeview=lookup_widget(windowplantation,"AStreeview");
	    ASsuppression(id,p);
            ASaffichage(AStreeview);
}


void
on_ASbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
}


void
on_ASbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ASentrymodifid;
		ASentrymodifid=lookup_widget(button,"ASentrymodifid");
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));	
		gtk_entry_set_text(GTK_ENTRY(ASentrymodifid),id);
}


void
on_ASbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
}


void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
GtkWidget *windowplantation;
GtkWidget *ASentryid;
GtkWidget *AStreeview;
GtkWidget *alert2;
FILE*f;
FILE*f2;
alert2=lookup_widget(button, "ASlabelalertrech");
windowplantation=lookup_widget(button,"windowplantation");
ASentryid=lookup_widget(button,"ASentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(ASentryid)));
if (AGverif(idrech)==0){gtk_label_set_text(GTK_LABEL(alert2),"Champs obligatoire!");}
else if (AGverif(idrech)==1){
f=fopen("plantations.bin","rb");

 if(f!=NULL)
 {
  while(fread(&p,sizeof(PLANTE),1,f))
     {
       f2=fopen("ASrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (((strcmp(p.identifiant,idrech)==0))||((strcmp(p.type,idrech)==0)))
     { 
     fwrite(&p,sizeof(PLANTE),1,f2);
     }
   
     AStreeview=lookup_widget(windowplantation,"AStreeview");
     ASrecherche(AStreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("ASrecherche.bin");}
}


void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char Type[30];char x[30];
PLANTE p;
GtkWidget *ASentryajoutid;
GtkWidget *ASspinbuttonajoutnbr;
GtkWidget *ASspinbuttonajoutrecolte;
GtkWidget *ASspinbuttonajoutjour;
GtkWidget *ASspinbuttonajoutmois;
GtkWidget *ASspinbuttonajoutannee;
GtkWidget *AScomboboxajouttype;
GtkWidget *sortiea;
GtkWidget *alert1;


ASspinbuttonajoutjour=lookup_widget(button, "ASspinbuttonajoutjour");
ASspinbuttonajoutmois=lookup_widget(button, "ASspinbuttonajoutmois");
ASspinbuttonajoutannee=lookup_widget(button, "ASspinbuttonajoutannee");
AScomboboxajouttype=lookup_widget(button, "AScomboboxajouttype");
ASentryajoutid=lookup_widget(button,"ASentryajoutid");
ASspinbuttonajoutnbr=lookup_widget(button, "ASspinbuttonajoutnbr");
ASspinbuttonajoutrecolte=lookup_widget(button, "ASspinbuttonajoutrecolte");
sortiea=lookup_widget(button, "ASlabelmsgsucc");
alert1=lookup_widget(button, "ASlabelajoutalertid");

strcpy(x,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
if (AGverif(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"Champs obligatoire!");}
else if (AGverif(x)==1){
	if(verifid(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"ID existe déjà");}

	else if(verifid(x)==1){
strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxajouttype)));
strcpy(p.type,Type);
ASajout(p);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");}}
}


void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;char Type[30];
GtkWidget *AScomboboxmodiftype;
GtkWidget *ASentrymodifid;
GtkWidget *ASspinbuttonmodifnbr;
GtkWidget *ASspinbuttonmodifjour;
GtkWidget *ASspinbuttonmodifmois;
GtkWidget *ASspinbuttonmodifannee;
GtkWidget *ASspinbuttonmodifrecolte;
GtkWidget *sortiem;    
	
ASspinbuttonmodifjour=lookup_widget(button, "ASspinbuttonmodifjour");
ASspinbuttonmodifmois=lookup_widget(button, "ASspinbuttonmodifmois");
ASspinbuttonmodifannee=lookup_widget(button, "ASspinbuttonmodifannee");
AScomboboxmodiftype=lookup_widget(button, "AScomboboxmodiftype");
ASentrymodifid=lookup_widget(button,"ASentrymodifid");
ASspinbuttonmodifnbr=lookup_widget(button, "ASspinbuttonmodifnbr");
ASspinbuttonmodifrecolte=lookup_widget(button, "ASspinbuttonmodifrecolte");
sortiem=lookup_widget(button, "ASlabelmodifreus");




strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentrymodifid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxmodiftype)));
strcpy(p.type,Type);
ASmodification(id,p);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_ASbuttonseche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *laba,*labr;
PLANTE p;
int a,r ; 
char seche[100] ; 
char rec[100];  


laba=lookup_widget(button,"ASlabela");
labr=lookup_widget(button,"ASlabelr");

a=anneeseche(p) ; 
r=recoltemin(p) ; 

sprintf(seche,"%d",a);
sprintf(rec,"%d",r);

gtk_label_set_text(GTK_LABEL(laba),seche);
gtk_label_set_text(GTK_LABEL(labr),rec);
}


void
on_ASbuttonmenup_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowmenu();
gtk_widget_show (window99);
}


void
on_menuplantation_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowplantation();
gtk_widget_show (window99);
}




void
on_nb_buttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR a;
GtkWidget *windowcapteurs;
GtkWidget *nb_entryid;
GtkWidget *nb_treeview;
FILE*f;
FILE*f2;


windowcapteurs=lookup_widget(button,"windowcapteurs");
nb_entryid=lookup_widget(button,"nb_entryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(nb_entryid)));
f=fopen("capteurs.bin","rb");

 if(f!=NULL)
 {
  while(fread(&a,sizeof(CAPTEUR),1,f))
    {
     
    if ((strcmp(a.identifiant,idrech)==0))
    {
    f2=fopen("nb_recherche.bin","ab+");
    if  (f2!=NULL) 
       {fwrite(&a,sizeof(CAPTEUR),1,f2);
     
       fclose(f2);
       }
    }

 }
 fclose(f);
}
nb_treeview=lookup_widget(windowcapteurs,"nb_treeview");
     nb_recherche(nb_treeview);
remove("nb_recherche.bin");
}


void
on_nb_treeview_row_activated            (GtkTreeView     *nb_treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(nb_treeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_nb_buttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nb_treeview;
windowcapteurs=lookup_widget(button,"windowcapteurs");
nb_treeview=lookup_widget(windowcapteurs,"nb_treeview");
nb_affichage(nb_treeview);
}


void
on_nb_buttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR a;
    GtkWidget *nb_treeview;
	    windowcapteurs=lookup_widget(button,"windowcapteurs");
	    nb_treeview=lookup_widget(windowcapteurs,"nb_treeview");
	    nb_suppression(id,a);
            nb_affichage(nb_treeview);
}


void
on_nb_buttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteurs,"nb_notebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteurs,"nb_notebook")));
}


void
on_nb_buttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR a;char Type[30];
GtkWidget *nb_entryajoutid;
GtkWidget *nb_entryajoutmarque;
GtkWidget *nb_entryajoutemplacement;
GtkWidget *nb_spinbuttonajoutjour;
GtkWidget *nb_spinbuttonajoutmois;
GtkWidget *nb_spinbuttonajoutannee;
GtkWidget *nb_comboboxajouttype;
GtkWidget *sortiea;

nb_spinbuttonajoutjour=lookup_widget(button, "nb_spinbuttonajoutjour");
nb_spinbuttonajoutmois=lookup_widget(button, "nb_spinbuttonajoutmois");
nb_spinbuttonajoutannee=lookup_widget(button, "nb_spinbuttonajoutannee");
nb_comboboxajouttype=lookup_widget(button, "nb_comboboxajouttype");
nb_entryajoutid=lookup_widget(button,"nb_entryajoutid");
nb_entryajoutmarque=lookup_widget(button,"nb_entryajoutmarque");
nb_entryajoutemplacement=lookup_widget(button,"nb_entryajoutemplacement");
sortiea=lookup_widget(button, "nb_labelmsgsucc");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(nb_entryajoutid)));
strcpy(a.marque,gtk_entry_get_text(GTK_ENTRY(nb_entryajoutmarque)));
strcpy(a.emplacement,gtk_entry_get_text(GTK_ENTRY(nb_entryajoutemplacement)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonajoutjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonajoutmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nb_comboboxajouttype)));
strcpy(a.type,Type);
nb_ajout(a);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_nb_buttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEUR a;char Type[30];
GtkWidget *nb_comboboxmodiftype;
GtkWidget *nb_entrymodifid;
GtkWidget *nb_entrymodifmarque;
GtkWidget *nb_spinbuttonmodifjour;
GtkWidget *nb_spinbuttonmodifmois;
GtkWidget *nb_spinbuttonmodifannee;
GtkWidget *nb_entrymodifemplacement;
GtkWidget *sortiem;    
	
nb_spinbuttonmodifjour=lookup_widget(button, "nb_spinbuttonmodifjour");
nb_spinbuttonmodifmois=lookup_widget(button, "nb_spinbuttonmodifmois");
nb_spinbuttonmodifannee=lookup_widget(button, "nb_spinbuttonmodifannee");
nb_comboboxmodiftype=lookup_widget(button, "nb_comboboxmodiftype");
nb_entrymodifid=lookup_widget(button,"nb_entrymodifid");
nb_entrymodifmarque=lookup_widget(button,"nb_entrymodifmarque");
nb_entrymodifemplacement=lookup_widget(button,"nb_entrymodifemplacement");
sortiem=lookup_widget(button, "nb_labelmodifreus");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(nb_entrymodifid)));
strcpy(a.marque,gtk_entry_get_text(GTK_ENTRY(nb_entrymodifmarque)));
strcpy(a.emplacement,gtk_entry_get_text(GTK_ENTRY(nb_entrymodifemplacement)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonmodifjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonmodifmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nb_spinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nb_comboboxmodiftype)));
strcpy(a.type,Type);
nb_modification(id,a);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}





void
on_nb_cd_button_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_menucapteurs_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window99;
window99=create_windowcapteurs();
gtk_widget_show (window99);
}


void
on_ABradiobutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x1=1;}
}

}


void
on_ABradiobutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x1=0;}
}

}


void
on_ABradiobutton4_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x2=1;}
}

}


void
on_ABradiobutton3_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x2=0;}
}

}



void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
int nb;
char chnb[30];
GtkWidget *nbResultat,*message,*window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *p1=lookup_widget(window1,"treeview1");
nb=chercher_c(p1,"temperature.txt");
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(window1,"entry82");
//message=lookup_widget(window1,"label316");
gtk_entry_set_text(GTK_ENTRY(nbResultat),chnb);
//gtk_widget_show (message);
gtk_widget_show (nbResultat);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window990;
window990=create_window1();
gtk_widget_show (window990);
}







