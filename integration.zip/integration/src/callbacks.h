#include <gtk/gtk.h>


void
on_buttonlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoninscription_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoninscri_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestionouvrier_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonmenuprincipal_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbutton1tache2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBbutton2tache2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_DBtreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_DBtreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_ABbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABstatistique_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbuttonmodifier_clicked            (GtkButton       *windowtroupeaux,
                                        gpointer         user_data);

void
on_ABbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABtreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ABbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbutton6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);
//***************************************************************************************
void
on_actaff_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_marq_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_aff_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_mschr_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msmod_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mssup_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_msact_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);
//*************************************************************************************************************



void
on_YGbutton4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajaj_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonajeb_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajed_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_DBradiobutton2tache22_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_DBradiobutton1tache22_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_menuclients_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABbutton9_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_YGbutton9_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_KCbutton10_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_AStreeview_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonseche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonmenup_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_menuplantation_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_buttonrechercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_buttonactualiser_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_buttonmodifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_buttonsupprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_treeview_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_nb_buttonajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_buttonconfirmermodif_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_nb_cd_button_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_menucapteurs_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ABradiobutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ABradiobutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ABradiobutton4_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ABradiobutton3_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
