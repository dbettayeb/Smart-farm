#include "fonction.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>






enum{DBSEXE,DBCIN,DBNOM,DBDATE,DBPRENOM,DBCOLUMNS};

void DBaffichage(GtkWidget* DBtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ouvrier o;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(DBtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",DBSEXE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (DBtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",DBCIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (DBtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",DBNOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (DBtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text",DBPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (DBtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date de recrutement", renderer, "text",DBDATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (DBtreeview), column);}

store=gtk_list_store_new(DBCOLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("ouvrier.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("ouvrier.bin","ab+");
while(fread(&o,sizeof(ouvrier),1,f))
{sprintf(Date,"%d/%d/%d",o.date.jour,o.date.mois,o.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,DBSEXE,o.sexe,DBCIN,o.cin,DBNOM,o.nom,DBDATE,Date,DBPRENOM,o.prenom,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(DBtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}


void presence (pointage p)
{FILE*f=NULL; 
f=fopen("pointage.txt","a+");
fprintf(f, "%s %d %d %d %d\n",p.cin,p.date.jour,p.date.mois,p.date.annee,p.present);  
fclose(f);}


void DBajout (ouvrier o){
FILE*f=NULL; 
f=fopen("ouvrier.bin","ab+");
fwrite(&o,sizeof(ouvrier),1,f);  
fclose(f);
 
}

void DBsuppression(char id[30],ouvrier o){
FILE*f;
FILE*g;
f=fopen("ouvrier.bin","rb+");
g=fopen("DBtmp.bin","wb+");
if(g!=NULL){
while(fread(&o,sizeof(ouvrier),1,f))
{
if (strcmp(o.cin,id)!=0){
fwrite(&o,sizeof(ouvrier),1,g);

}
}
}fclose(f);
fclose(g);
remove("ouvrier.bin");
rename("DBtmp.bin","ouvrier.bin");
}



void DBmodification(char id[30],ouvrier o)
{

	DBsuppression(id,o);
	DBajout(o);

}

void DBrecherche(GtkWidget* DBtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;ouvrier o;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(DBtreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",DBSEXE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(DBtreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("CIN",renderer, "text",DBCIN,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(DBtreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",DBNOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(DBtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DBDATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(DBtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",DBPRENOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(DBtreeview), column);}
  
store=gtk_list_store_new(DBCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("DBrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("DBrecherche.bin", "ab+");
    while(fread(&o,sizeof(ouvrier),1,f2))
     {sprintf(Date,"%d/%d/%d",o.date.jour,o.date.mois,o.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,DBSEXE,o.sexe,DBCIN,o.cin,DBNOM,o.nom,DBDATE,Date,DBPRENOM,o.prenom, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (DBtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


int checkpassword(char mot1[],char mot2[])
{
int verif=-1;
if((strcmp(mot1,mot2)==0))
verif=1;
else
verif=0;
return verif;
}


int verif(char mot1[],char mot2[])
{
int trouve=-1;
FILE * f;
char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];

f=fopen("inscription.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5)!=EOF)
{
if((strcmp(ch3,mot1)==0)&&(strcmp(ch4,mot2)==0))
trouve=1;
}
fclose(f);
}
else
printf("\n not found");
return trouve;

}

//*****************************************troupeaux*****************************************************************

enum{TYPE,IDENTIFIANT,SEXE,DATE,POIDS,COLUMNS};
//------------------------------------------------------********---------------------------------------------------
void ABaffichage(GtkWidget* ABtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ANIMAL a;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(ABtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (ABtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (ABtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",SEXE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (ABtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (ABtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Poids", renderer, "text",POIDS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (ABtreeview), column);}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("animaux.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("animaux.bin","ab+");
while(fread(&a,sizeof(ANIMAL),1,f))
{sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,a.type,IDENTIFIANT,a.identifiant,SEXE,a.sexe,DATE,Date,POIDS,a.poids,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(ABtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}


//-------------------------------------------------------*******-----------------------------------------------------------

void ABajout (ANIMAL a){
FILE*f=NULL; 
f=fopen("animaux.bin","ab+");
fwrite(&a,sizeof(ANIMAL),1,f);  
fclose(f);
 
}
//------------------------------------------------------------------------------------------------------------------------

void ABsuppression(char id[30],ANIMAL a){
FILE*f;
FILE*g;
f=fopen("animaux.bin","rb+");
g=fopen("ABtmp.bin","wb+");
if(g!=NULL){
while(fread(&a,sizeof(ANIMAL),1,f))
{
if (strcmp(a.identifiant,id)!=0){
fwrite(&a,sizeof(ANIMAL),1,g);

}
}
}fclose(f);
fclose(g);
remove("animaux.bin");
rename("ABtmp.bin","animaux.bin");
}

//------------------------------------------------------------------------------------------------------------------------

void ABmodification(char id[30],ANIMAL a)
{

	ABsuppression(id,a);
	ABajout(a);

}
//------------------------------------------------------------------------------------------------------------------------
void ABrecherche(GtkWidget* ABtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;ANIMAL a;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(ABtreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(ABtreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(ABtreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(ABtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(ABtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Poids",renderer, "text",POIDS,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(ABtreeview), column);}
  
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("ABrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("ABrecherche.bin", "ab+");
    while(fread(&a,sizeof(ANIMAL),1,f2))
     {sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE,a.type,IDENTIFIANT,a.identifiant,SEXE,a.sexe,DATE,Date,POIDS,a.poids, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (ABtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//------------------------------------------------------------------------------------------------------------------------


void nombre(int *b,int *v)
{
FILE *f;
ANIMAL a; 
f=fopen("animaux.bin","rb");
while (fread(&a,sizeof(a),1,f))
if (strcmp(a.type,"Brebi")==0)
*b+=1;
else 
if (strcmp(a.type,"Veau")==0)
*v+=1;
fclose(f);
}
//--------------------------------------------------------------------------------------------------------------------------


//**************************************************************************************************************************
enum   
{       REF,
	NOM,
	MARQUE,
        YGDATE,	
        DATEM,
	ETAT,
	YGCOLUMNS,
};




void ajouter_equipement(equipement e)
{
  FILE *f;
  f=fopen("equip.txt","a+");
  if(f!=NULL) 
{
  fprintf(f,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);
  fclose(f);
}
  f=fopen("equip1.txt","a+");
  if(f!=NULL) 
{
  fprintf(f,"%s %s %s %d/ %d/ %d %d/ %d/ %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);
  fclose(f);
}
}
void afficher_equipement(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char nom[30];
	char marque[15];
	char jour[5];
	char mois[5];
	char annee[6];
	char jourm[5];
	char moism[5];
	char anneem[6];
	char date[30];
	char datem[20];
	char etat[30];

	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Reference",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",MARQUE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date_d_achat",renderer, "text",YGDATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date_de_maintenance",renderer, "text",DATEM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


 		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Etat",renderer, "text",ETAT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		



		

		store=gtk_list_store_new (YGCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("equip1.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("equip1.txt","a+");
			while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",ref,nom,marque,jour,mois,annee,jourm,moism,anneem,etat)!=EOF)
			{strcpy(date, jour);
			 strcat(date, mois);
			 strcat(date, annee);

			 strcpy(datem, jourm);
			 strcat(datem, moism);
			 strcat(datem, anneem);
		gtk_list_store_append(store,&iter);
		gtk_list_store_set (store, &iter, REF, ref, NOM, nom, MARQUE, marque, YGDATE, date, DATEM, datem, ETAT, etat, -1 );
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
 		g_object_unref(store);
}
}
}




void modifier_equipement(equipement e1)
{
    FILE*f;
    FILE*c;
    FILE*s;
    FILE*l;
    equipement e;
    char ref[9];
    f=fopen("equip.txt","r");
    c=fopen("tmp.txt","a+");
    s=fopen("tmp1.txt","a+");

    
    if(f!=NULL)
    { if(c!=NULL)
    { 
        while(fscanf(f,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,&e.jour,&e.mois,&e.annee,&e.jourm,&e.moism,&e.anneem,e.etat)!=EOF)
        {
		printf("\n %s \n",e1.ref);
            if(strcmp(e.ref,e1.ref)!=0)
            {
                fprintf(c,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);
		fprintf(s,"%s %s %s %d/ %d/ %d %d/ %d/ %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);	
			printf("\n oki \n");

            }
            else
            { printf("\n oki1 \n");



                fprintf(c,"%s %s %s %d %d %d %d %d %d %s\n",e1.ref,e1.nom,e1.marque,e1.jour,e1.mois,e1.annee,e1.jourm,e1.moism,e1.anneem,e1.etat);
		fprintf(s,"%s %s %s %d/ %d/ %d %d/ %d/ %d %s\n",e1.ref,e1.nom,e1.marque,e1.jour,e1.mois,e1.annee,e1.jourm,e1.moism,e1.anneem,e1.etat);
            }
        }
        fclose(f);
        fclose(c);
        fclose(s);
remove("equip.txt");
rename("tmp.txt","equip.txt");
remove("equip1.txt");
rename("tmp1.txt","equip1.txt");
    }
    }

}
equipement rechercher (char ref[15])
{
    FILE*f;

equipement e;
    

    f=fopen("equip.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,&e.jour,&e.mois,&e.annee,&e.jourm,&e.moism,&e.anneem,e.etat)!=EOF)
    {
        if((strcmp(e.ref,ref)==0))
        {
	 printf("ok \n");
	return e;
fclose(f);
	}
        
		strcpy(e.ref,"erreur");
		strcpy(e.nom,"erreur");
		strcpy(e.marque,"erreur");
                strcpy(e.etat,"erreur");
                
                

			    
    }
	
    fclose (f);}
    return e;

}

int supprimer_equipement(equipement e,char ref[15])
{
    FILE*f;
    FILE*c;
    FILE*s;
    int suppri=0;
    f=fopen("equip.txt","r+");
    c=fopen("tmp.txt","w+");
    s=fopen("tmp1.txt","w+");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,&e.jour,&e.mois,&e.annee,&e.jourm,&e.moism,&e.anneem,e.etat)!=EOF)
        {

            if ((strcmp(e.ref,ref)!=0))
            {               
                fprintf(c,"%s %s %s %d %d %d %d %d %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);
		fprintf(s,"%s %s %s %d/ %d/ %d %d/ %d/ %d %s\n",e.ref,e.nom,e.marque,e.jour,e.mois,e.annee,e.jourm,e.moism,e.anneem,e.etat);              
            }
            else
            {
              suppri=1;
            }
        }
    }
fclose(f);
fclose(c);
fclose(s);
remove("equip.txt");
rename("tmp.txt","equip.txt");

remove("equip1.txt");
rename("tmp1.txt","equip1.txt");
return suppri;
}

/*absence meilleur ()
{
    FILE*f;

absence a;
absence a1;
    int t=101;

    f=fopen("abs.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
    {
     if(a.taux < t)
        {
	 t=a.taux;
	 a1=a;
	}
                
    }
	
    fclose (f);}
    return a1;

}*/




//*******************************************************************************************************************************
GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;
int k,l,h;
int chercher_c(GtkWidget* treeview1,char*l)
{

capteur c;
int nb=0;
float min=0;
float max=44;
        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     G_TYPE_STRING,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_FLOAT);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %d %d %d %f\n",c.ref,&c.dt.jour,&c.dt.mois,&c.dt.annee,&c.valeur)!=EOF)
        {
if(c.valeur>=max || c.valeur<=min){nb++;
GtkTreeIter pIter;
         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,c.ref,
                            1,c.dt.jour,
                            2,c.dt.mois,
                            3,c.dt.annee,
                            4,c.valeur,-1);}
}
        fclose(f);

/* Creation de la 1ere colonne */
if(h==0)
{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Reference",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);



/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Jour",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
/* Ajouter la 4emme colonne à la vue */
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

/* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Mois",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
/* Ajouter la 5emme colonne à la vue */
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

        /* Creation de la 6eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Annee",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
/* Ajouter la 6emme colonne à la vue */
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);    
       
         /* Creation de la 7eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Valeur",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
/* Ajouter la 7emme colonne à la vue */
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);  

h++;}


  gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );
return nb;
}

void ajouter_client( client c){
FILE*f=NULL;
f=fopen("clients.txt","a+");//(+) creation du fichier sil nexsite pas
fprintf(f,"%s %s %s %s  %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel );
fclose(f);

}

int exist_client(char*cin){
FILE*f=NULL;
 client c;
f=fopen("clients.txt","r");
while(fscanf(f,"%s %s %s %s  %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF){
if(strcmp(c.cin,cin)==0)return 1;
}
fclose(f);
return 0;
}

void modifier(char*cin)
{
FILE*f=NULL;
FILE*f1=NULL;
client c ;
f=fopen("clients.txt","r");
f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s  %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF){
if( strcmp(c.cin,cin)!=0)
{
fprintf(f1,"%s %s %s %s   %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel);
}
else
{
fprintf(f1,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel);
}

}
fclose(f);
fclose(f1);

remove("clients.txt");
rename("ancien.txt","clients.txt");
}

void supprimer_client(char*cin){
FILE*f=NULL;
FILE*f1=NULL;
client c ;
f=fopen("clients.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %s \n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF){
if(strcmp(cin,c.cin)!=0)fprintf(f1,"%s %s %s %s %s \n",c.cin,c.nom,c.prenom,c.adresse,c.numtel);
}
fclose(f);
fclose(f1);
remove("clients.txt");
rename("ancien.txt","clients.txt");
}

GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;
void AfficherClient(GtkWidget* treeview1,char*l)
{

client c;
int i;

        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_STRING,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,c.cin,
                            1,c.nom,
                            2,c.prenom,
                            3,c.adresse,
                            4,c.numtel,
			  
                            -1);}
        fclose(f);

	/* Creation de la 1ere colonne */
if(i==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CIN",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 3eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ADERESSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NUMTEL",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
        


	i++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );

}



void AfficherClient1(GtkWidget* treeview1,char*l)
{

client c;
int j;

        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				    
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF)
        {GtkTreeIter pIter;
	
         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,c.cin,
                            1,c.nom,
                            2,c.prenom,
                            3,c.adresse,
                            4,c.numtel,
			   
                            -1);}
        fclose(f);

	/* Creation de la 1ere colonne */
if(j==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CIN",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 3eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ADERESSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NUMTEL",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);
	
	


	j++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );

}



int ChercherClient(GtkWidget* treeview1,char*l,char*cin)
{

client c;

int nb=0;
int i,j;

        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING, 
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s  %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF)
        {
	if( strcmp(cin,c.cin)==0){ nb++;
	GtkTreeIter pIter;
         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,c.cin,
                            1,c.nom,
                            2,c.prenom,
                            3,c.adresse,
                            4,c.numtel,
			   
                            -1);}
}
        fclose(f);

	/* Creation de la 1ere colonne */
if(j==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("CIN",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NOM",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 3eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("PRENOM",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ADERESSE",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("NUMTEL",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	

	j++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );
return nb;
}




//-------------------------------------------------------Plantations---------------------------------------------------------------------
enum{AGTYPE,AGIDENTIFIANT,NOMBRE,AGDATE,RECOLTE,AGCOLUMNS};

void ASaffichage(GtkWidget* AStreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
PLANTE p;char Date[100];char Nbr[100];char Recolte[100]; 
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(AStreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",AGTYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",AGIDENTIFIANT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nombre", renderer, "text",NOMBRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",AGDATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Recolte", renderer, "text",RECOLTE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);}

store=gtk_list_store_new(AGCOLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("plantations.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f))
{sprintf(Date,"%d/%d/%d",p.date.jour,p.date.mois,p.date.annee);
sprintf(Nbr,"%d",p.nombre);
sprintf(Recolte,"%d",p.recolte);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,AGTYPE,p.type,AGIDENTIFIANT,p.identifiant,NOMBRE,Nbr,AGDATE,Date,RECOLTE,Recolte,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(AStreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}




void ASajout (PLANTE p){
FILE*f=NULL; 
f=fopen("plantations.bin","ab+");
fwrite(&p,sizeof(PLANTE),1,f);  
fclose(f);
 
}


void ASsuppression(char id[30],PLANTE p){
FILE*f;
FILE*g;
f=fopen("plantations.bin","rb+");
g=fopen("AStmp.bin","wb+");
if(g!=NULL){
while(fread(&p,sizeof(PLANTE),1,f))
{
if (strcmp(p.identifiant,id)!=0){
fwrite(&p,sizeof(PLANTE),1,g);

}
}
}fclose(f);
fclose(g);
remove("plantations.bin");
rename("AStmp.bin","plantations.bin");
}



void ASmodification(char id[30],PLANTE p)
{

	ASsuppression(id,p);
	ASajout(p);

}

void ASrecherche(GtkWidget* AStreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;PLANTE p;
 FILE *f2;char Date[100];char Nbr[100];char Recolte[100]; 
 store=gtk_tree_view_get_model(AStreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",AGTYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",AGIDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Nombre",renderer, "text",NOMBRE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",AGDATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Recolte",renderer, "text",RECOLTE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);}
  
store=gtk_list_store_new(AGCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("ASrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("ASrecherche.bin", "ab+");
    while(fread(&p,sizeof(PLANTE),1,f2))
{sprintf(Date,"%d/%d/%d",p.date.jour,p.date.mois,p.date.annee);
sprintf(Nbr,"%d",p.nombre);
sprintf(Recolte,"%d",p.recolte);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,AGTYPE,p.type,AGIDENTIFIANT,p.identifiant,NOMBRE,Nbr,AGDATE,Date,RECOLTE,Recolte, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (AStreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}}

int anneeseche (PLANTE p)
{FILE*f;
int i,min,ann,aux,aux1,aux2,permut,k,j=0,n=0;

//détermination du nombre des lignes dans mon fichier binaire

f=fopen("plantations.bin","rb");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
	n++;}

fclose(f);

//initialisation de mon tableau et son remplissage

int t[2][n];
f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
		
if(j<n){
			t[0][j]=p.date.annee;
			t[1][j]=p.recolte;
j++;
			}}	
fclose(f); 

//Tri des années
do
{
permut=0; 
for( i=0 ;i<n-1;i++ )
{
if (t[0][i]>t[0][i+1])
{

aux1=t[0][i];
aux2=t[1][i];

t[0][i]=t[0][i+1];
t[1][i]=t[1][i+1];

t[0][i+1]=aux1;
t[1][i+1]=aux2;

permut=1;
}
}
}
while (permut == 1);

//suppression des années dupliquées et somme des récoltes de chaque année

   for (i=0;i<n;i++) {
      for (j=i+1;j<n;) {
         if (t[0][j]==t[0][i]) {t[1][i]=t[1][i]+t[1][i+1];
            for (k=j;k<n;k++) {
               t[0][k]=t[0][k+1];
	       t[1][k]=t[1][k+1];
            }
            n--;
         } else
            j++;
      }
   }
//Determination de l'année la plus sèche
        ann=t[0][0];
	min=t[1][0];
    for(i=1;i<n;i++)
    {
       if(t[1][0] > t[1][i])
          { min=t[1][i];
	   ann=t[0][i];}
    }
	return ann;

	}		

int recoltemin(PLANTE p)
{FILE*f;
int i,min,ann,aux,aux1,aux2,permut,k,j=0,n=0;

//détermination du nombre des lignes dans mon fichier binaire

f=fopen("plantations.bin","rb");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
	n++;}

fclose(f);

//initialisation de mon tableau et son remplissage

int t[2][n];
f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
		
if(j<n){
			t[0][j]=p.date.annee;
			t[1][j]=p.recolte;
j++;
			}}	
fclose(f); 

//Tri des années
do
{
permut=0; 
for( i=0 ;i<n-1;i++ )
{
if (t[0][i]>t[0][i+1])
{

aux1=t[0][i];
aux2=t[1][i];

t[0][i]=t[0][i+1];
t[1][i]=t[1][i+1];

t[0][i+1]=aux1;
t[1][i+1]=aux2;

permut=1;
}
}
}
while (permut == 1);

//suppression des années dupliquées et somme des récoltes de chaque année

   for (i=0;i<n;i++) {
      for (j=i+1;j<n;) {
         if (t[0][j]==t[0][i]) {t[1][i]=t[1][i]+t[1][i+1];
            for (k=j;k<n;k++) {
               t[0][k]=t[0][k+1];
	       t[1][k]=t[1][k+1];
            }
            n--;
         } else
            j++;
      }
   }
//Determination de l'année la plus sèche
        ann=t[0][0];
	min=t[1][0];
    for(i=1;i<n;i++)
    {
       if(t[1][0] > t[1][i])
          { min=t[1][i];
	   ann=t[0][i];}
    }
	return min;

	}

int AGverif(char x[])
{
   int i=0;
   if (strcmp(x, "")==0)
   {
      i=0;
   }
   else
   {
      i=1;
   }
   return i;
}
int verifid(char id[30])
{
   PLANTE p;
   int res = 1;
   FILE *f;
   f = fopen("plantations.bin", "ab+");
   if (f != NULL)
   {
      while (fread(&p,sizeof(PLANTE),1,f))
      {
         if (strcmp(id,p.identifiant) == 0)
         {
            res = 0;
         }
         else
         {
            res = 1;
         }
      }
   }
   fclose(f);
   return res;
}




enum{NBTYPE,NBIDENTIFIANT,NBMARQUE,NBDATE,NBEMPLACEMENT,NBCOLUMNS};
//------------------------------------------------------********---------------------------------------------------
void nb_affichage(GtkWidget* nb_treeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
CAPTEUR a;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(nb_treeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",NBTYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (nb_treeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",NBIDENTIFIANT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (nb_treeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Marque", renderer, "text",NBMARQUE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (nb_treeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",NBDATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (nb_treeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Emplacement", renderer, "text",NBEMPLACEMENT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (nb_treeview), column);}

store=gtk_list_store_new(NBCOLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("capteurs.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("capteurs.bin","ab+");
while(fread(&a,sizeof(CAPTEUR),1,f))
{sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NBTYPE,a.type,NBIDENTIFIANT,a.identifiant,NBMARQUE,a.marque,NBDATE,Date,NBEMPLACEMENT,a.emplacement,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(nb_treeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}


//-------------------------------------------------------*******-----------------------------------------------------------

void nb_ajout (CAPTEUR a){
FILE*f=NULL; 
f=fopen("capteurs.bin","ab+");
fwrite(&a,sizeof(CAPTEUR),1,f);  
fclose(f);
 
}
//------------------------------------------------------------------------------------------------------------------------

void nb_suppression(char id[30],CAPTEUR a){
FILE*f;
FILE*g;
f=fopen("capteurs.bin","rb+");
g=fopen("ABtmp.bin","wb+");
if(g!=NULL){
while(fread(&a,sizeof(CAPTEUR),1,f))
{
if (strcmp(a.identifiant,id)!=0){
fwrite(&a,sizeof(CAPTEUR),1,g);

}
}
}fclose(f);
fclose(g);
remove("capteurs.bin");
rename("ABtmp.bin","capteurs.bin");
}

//------------------------------------------------------------------------------------------------------------------------

void nb_modification(char id[30],CAPTEUR a)
{

	nb_suppression(id,a);
	nb_ajout(a);

}
//------------------------------------------------------------------------------------------------------------------------
void nb_recherche(GtkWidget* nb_treeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;CAPTEUR a;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(nb_treeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",NBTYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(nb_treeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",NBIDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(nb_treeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",NBMARQUE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(nb_treeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",NBDATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(nb_treeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Emplacement",renderer, "text",NBEMPLACEMENT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(nb_treeview), column);}
  
store=gtk_list_store_new(NBCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("nb_recherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("nb_recherche.bin", "ab+");
    while(fread(&a,sizeof(CAPTEUR),1,f2))
     {sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,NBTYPE,a.type,NBIDENTIFIANT,a.identifiant,NBMARQUE,a.marque,NBDATE,Date,NBEMPLACEMENT,a.emplacement, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (nb_treeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


//------------------------------------
int deffectueux (int iden [], char *fichier, float minv , float maxv )
{   FILE *f;
    Capteur c;
    int n=0,i,t,k=0;
    int max;
    int id;
    f=fopen(fichier,"r");
    if(f!=NULL)
 {
    while(fscanf(f,"%d %d %d %d %f",&c.id,&c.jour,&c.mois,&c.annee,&c.val)!=EOF)
    {   //printf("id=%d val=%f\n",c.id,c.val);
        if(c.val>maxv||c.val<minv)
        {

                   iden[n]=c.id;
                   n++;
               }
           }
        }
         fclose(f);
    i=0;
    max=0;
    for(i=0;i<n;i++){
        for(t=0;t<n;t++){
            if(iden[i]==iden[t]){
                k++;
        }   }
        if(max<k)
        {   max=k;
            id=iden[i];
    //printf("l'element %d apparait %d fois!\n",iden[i],k);
    }
    k=0;
    }
    i=0;
    while(i<n)
    {
        for(t=i+1;t<n;t++)
        {
            if(iden[i]==iden[t])
            {iden[t]=0;}
        }
        i++;
    }
    for(i=0;i<n;i++)
    {  if(iden[i]!=0)
        printf("%d/",iden[i]);
    }
    return id;
}
/*capteur cherchercapt(char *id,char *marque)
{   FILE *f;
    Capteur c;
    int n=0,i,t,id;
    char marques[20];
    f=fopen(marque,"r");

    strcpy(Marque,"");
    if(f!=NULL)
    {

    while(fscanf(f,"%s %d",&marques,&id)!=EOF)
    {

    }
    }
             fclose(f);

}*/
int marquedef ()
{
FILE *f;
int i,j;
int deft=0;
int def[30];
int T[20];
char M[500][20];
int d;
char marque [20];
int n=deffectueux(T,"temperature.txt",-5,60.5);
//printf("\n%d\n",n);
int nbr=0;
f=fopen("marque.txt","r");
    if(f!=NULL)
 {
while(fscanf(f,"%s %d",marque,&d)!=EOF)
{
    //for(i=0;i<n;i++)
//{
 //cherchercapt(T,marque);
  //for(j=0;j<nbr&&strcmp(M[j],marque)!=0;j++)
  //{ //printf("boucle");
      //if(j==nbr)
      //{
          strcpy(M[nbr],marque);
          def[nbr]=0;
          nbr++;


      //}
      //else
      //def[j]++;

  }
//}
}
 //}
 fclose(f);
 i=0;
 while(i<nbr)
 {
     for(j=i+1;j<nbr;j++)
        {
            if(strcmp(M[i],M[j])==0)
            {strcpy(M[j],"00000");
            }
        }
        i++;
 }
 printf("\n");
 for(j=0;j<nbr;j++)
    {if(strcmp(M[j],"00000")!=0)
    {printf("/%s/",M[j]);
    deft++;}}
    //printf("%d",deft);
    printf("\n");

   /*for(j=0;j<deft;j++)
   {printf("/%d/",def[j]);}*/
   printf("\n");
   printf("la marque la plus defectueuse est %s ",M[n-1]);
   return def;

}

//cherchercapt( )










