
#include <gtk/gtk.h>

int checkpassword(char mot1[],char mot2[]);
int verif(char mot1[],char mot2[]);
//-------------------------------------troupeaux------------------------------------------------------------
typedef struct
{
int jour;
int mois;
int annee;
}Datee;
typedef struct
{
char cin[20];
int present;
Datee date;
}pointage;

typedef struct
{
char sexe[30];
char cin[30];
char nom[30];
char prenom[30];
Datee date;
}ouvrier;
void presence (pointage p);
void DBajout(ouvrier o);
void DBrecherche(GtkWidget* DBtreeview);
void DBsuppression(char id[30], ouvrier o);
void DBaffichage(GtkWidget* DBtreeview);
void DBmodification(char id[30], ouvrier o);



typedef struct
{
char type[30];
char identifiant[30];
char sexe[30];
char poids[30];
Datee date;
}ANIMAL;

void ABajout(ANIMAL a);
void ABrecherche(GtkWidget* ABtreeview);
void ABsuppression(char id[30], ANIMAL a);
void ABaffichage(GtkWidget* ABtreeview);
void ABmodification(char id[30], ANIMAL a);
void nombre(int *b,int *v);


//---------------------------------------------------------------------------------------------------------------

//*******************************************************************************************************************
#include <gtk/gtk.h>

struct equipement
{

	char ref[30];
	char nom[30];
	char marque[15];
	int jour;
	int mois;
	int annee;
	int jourm;
	int moism;
	int anneem;
	char etat[30];



}; typedef struct equipement equipement;

void ajouter_equipement(equipement e);
void afficher_equipement(GtkWidget *liste);
void afficher_defectueux(GtkWidget *liste);
void modifier_equipement(equipement e1);
equipement rechercher (char ref[15]);
int supprimer_equipement(equipement,char ref[15]);
//absence recherch (char cin[15]);
//void modifier_marque(marque m1);
//marque mauvaise ();

//******************************
typedef struct {
char cin[30];
char nom[30];
char prenom[30];
char adresse[30];
char numtel[9];

} client;


void ajouter_client( client c);
int exist_client(char*cin);
void supprimer_client(char*cin);
void modifier(char*cin);






void AfficherClient(GtkWidget* treeview1,char*l);
void AfficherClient1(GtkWidget* treeview1,char*l);
int ChercherClient(GtkWidget* treeview1,char*l,char*cin);
typedef struct Date1 Date1;
struct Date1{
int jour;
int mois;
int annee;
};

typedef struct capteur capteur;
struct capteur{
char type[20];
char marque[20];
char ref[20];
float valeur;
Date1 dt;
};
int chercher_c(GtkWidget* treeview1,char*l);

//****************************************************
typedef struct
{
int jour;
int mois;
int annee;
}Dateee;


typedef struct
{
char type[30];
char identifiant[30];
int nombre;
int recolte;
Dateee date;
}PLANTE;

void ASajout(PLANTE p);
void ASrecherche(GtkWidget* AStreeview);
void ASsuppression(char id[30], PLANTE p);
void ASaffichage(GtkWidget* AStreeview);
void ASmodification(char id[30], PLANTE p);
int anneeseche(PLANTE p);
int recoltemin(PLANTE p);
int AGverif(char x[]);
int verifid(char id[30]);
//*************************************************************************



typedef struct
{
char type[30];
char identifiant[30];
char marque[30];
char emplacement[30];
Datee date;
}CAPTEUR;

void nb_ajout(CAPTEUR a);
void nb_recherche(GtkWidget* nb_treeview);
void nb_suppression(char id[30], CAPTEUR a);
void nb_affichage(GtkWidget* nb_treeview);
void nb_modification(char id[30], CAPTEUR a);


typedef struct
{
    int id;
    int jour;
    int mois;
    int annee;
    float val;
}Capteur;

int deffectueux (int iden [], char *fichier, float minv , float maxv );
int marquedef();



